package util

func init() {
	clientInit()
}
